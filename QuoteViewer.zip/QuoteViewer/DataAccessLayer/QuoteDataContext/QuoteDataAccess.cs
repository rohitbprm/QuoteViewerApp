﻿using DomainLayer.IDataAccess;
using DomainLayer.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.QuoteDataContext
{
   public class QuoteDataAccess: IQuoteDataAccess
    {
        public QuoteDataAccess()
        {

        }

        public async Task<T> LoadQuoteData<T>(int limit, int offset)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                       | SecurityProtocolType.Tls11
                       | SecurityProtocolType.Tls12
                       | SecurityProtocolType.Ssl3;
                // Skip validation of SSL/TLS certificate
        ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ConnectionInfo.Connection);

                    //client.DefaultRequestHeaders.Accept.Clear();
                    //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    //GET Method
                    HttpResponseMessage response = await client.GetAsync(ConnectionInfo.randomurlRelativePath+ "/en/random");
                    if (response.IsSuccessStatusCode)
                    {
                       return await response.Content.ReadAsAsync<T>();
                    }
                    else
                    {
                        throw new Exception("State is unsuccess");
                    }
                }
            }
            catch(Exception ex)
            {
                throw;
            }
        }
    }
}
