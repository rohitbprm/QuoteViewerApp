﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainLayer.Entities;
using DomainLayer.IDataAccess;
using DomainLayer.Utilities;

namespace BusinessLayer.QuoteBusinessLayer
{
   public class QuoteBusinessLayer
    {
        IQuoteDataAccess _quoteDataAccess;
        public QuoteBusinessLayer(IQuoteDataAccess quoteDataAccess)
        {
            _quoteDataAccess = quoteDataAccess;
        }

        public string LoadData(int count)
        {
            CustomLinkedList<QuoteData> Quotedata = new CustomLinkedList<QuoteData>();
            for (int i = 0; i < count; i++)
            {
                Quotedata.Add(_quoteDataAccess.LoadQuoteData<QuoteData>(0, 50).Result);
            }
          var sorteddata=  CustomLinkedList<QuoteData>.MergeSort(Quotedata);
            return sorteddata.Load();
        }
    }
}
