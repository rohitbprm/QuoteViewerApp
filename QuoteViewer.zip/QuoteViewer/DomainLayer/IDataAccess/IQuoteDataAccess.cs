﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.IDataAccess
{
    public interface IQuoteDataAccess
    {

        Task<T> LoadQuoteData<T>(int limit, int offset);
    }
}
