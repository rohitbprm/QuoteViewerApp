﻿using DomainLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Utilities
{
   public class CustomLinkedList<T> where T: QuoteData
    {
        private T currentdata;
        private CustomLinkedList<T> nextdata;
        public CustomLinkedList()
        {
            currentdata = default(T);
            nextdata = this;
        }
        public CustomLinkedList(T value)
        {
            currentdata = value;
            nextdata = this;
        }
        public CustomLinkedList<T> Add(T value)
        {
            CustomLinkedList<T> node = new CustomLinkedList<T>(value);
            if (this.nextdata == this)
            {
                node.nextdata = this;
                this.nextdata = node;
            }
            else
            {
                CustomLinkedList<T> temp = this.nextdata;
                node.nextdata = temp;
                this.nextdata = node;
            }
            return node;
        }
        public string Load()
        {
           return Load(this);
        }
        public string Load(CustomLinkedList<T> node)
        {
            List<QuoteData> res =new  List<QuoteData>();
            if (node == null)
                node = this;
            CustomLinkedList<T> snode = node;
            do
            {
                res.Add(node.currentdata);
                node = node.nextdata;
            }
            while (node != snode);

           return Newtonsoft.Json.JsonConvert.SerializeObject(res);
        }
        // merging two linked list
        public static CustomLinkedList<T> SortedMerge(CustomLinkedList<T> lst1, CustomLinkedList<T> lst2)
        {
            // Base cases
            if (lst1 == null)
                return lst2;

            else if (lst2 == null)
                return lst1;

            CustomLinkedList<T> result;
            var compareval = lst1.currentdata.text.CompareTo(lst2.currentdata.text);
            if (compareval<=0)
            {
                if (compareval == 0)
                {
                    var tempcompareval = lst1.currentdata.author.name.CompareTo(lst2.currentdata.author.name);
                    if (tempcompareval > 0)
                    {
                        result = lst2;
                        result.nextdata = SortedMerge(lst1, lst2.nextdata);
                    }
                    else
                    {
                        result = lst1;
                        result.nextdata = SortedMerge(lst1.nextdata, lst2);
                    }
                }
                else
                {
                    result = lst1;
                    result.nextdata = SortedMerge(lst1.nextdata, lst2);
                }
       
            }
            else
            {
                result = lst2;
                result.nextdata = SortedMerge(lst1, lst2.nextdata);
            }

            return result;
        }

        //splitting list into two halves
        public static CustomLinkedList<T>[] FrontBackSplit(CustomLinkedList<T> ptr)
        {
            // base case
            if (ptr == null || ptr.nextdata == null)
            {
                return new CustomLinkedList<T>[] { ptr, null };
            }
            CustomLinkedList<T> snode = ptr;
            CustomLinkedList<T> backward = ptr;
            CustomLinkedList<T> forward = ptr.nextdata;
           
            // Forward moves twice and backward moves once
            do
            {
                forward = forward.nextdata;
                if (forward != null)
                {
                    backward = backward.nextdata;
                    forward = forward.nextdata;
                }
            } while (ptr != snode);

            // splitting the linked list
            CustomLinkedList<T>[] arr = new CustomLinkedList<T>[] { ptr, backward.nextdata };
            backward.nextdata = null;

            return arr;
        }

        // Sorting linked list using merge sort.
        public static CustomLinkedList<T> MergeSort(CustomLinkedList<T> head)
        {
            // Base case
            if (head == null || head.nextdata == null)
            {
                return head;
            }

            CustomLinkedList<T>[] arr = FrontBackSplit(head);
            CustomLinkedList<T> first_half = arr[0];
            CustomLinkedList<T> second_half = arr[1];


            first_half = MergeSort(first_half);
            second_half = MergeSort(second_half);

            // merge the two sorted list into single list.
            return SortedMerge(first_half, second_half);
        }

        public int Gnodes()
        {
            return Gnodes(this);
        }
        public int Gnodes(CustomLinkedList<T> node)
        {
            if (node == null)
                node = this;
            int count = 0;
            CustomLinkedList<T> snode = node;
            do
            {
                count++;
                node = node.nextdata;
            }
            while (node != snode);
            System.Console.WriteLine("\nCurrent Node Value : " + node.currentdata.ToString());
            System.Console.WriteLine("\nTotal nodes :" + count.ToString());
            return count;
        }
        //static void Main(string[] args)
        //{
        //    CustomLinkedList<int> node1 = new CustomLinkedList<int>(100);
        //    node1.Delete();
        //    CustomLinkedList<int> node2 = node1.Add(200);
        //    node1.Delete();
        //    node2 = node1.Add(200);
        //    CustomLinkedList<int> node3 = node2.Add(300);
        //    CustomLinkedList<int> node4 = node3.Add(400);
        //    CustomLinkedList<int> node5 = node4.Add(500);
        //    node1.Gnodes();
        //    node3.Gnodes();
        //    node5.Gnodes();
        //    node1.Load();
        //    node5.Delete();
        //    node2.Load();
        //    node1.Gnodes();
        //    node2.Gnodes();
        //    node5.Gnodes();
        //    Console.Read();
        //}
    }
}
