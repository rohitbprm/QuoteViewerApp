﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Utilities
{
   public static class ConnectionInfo
    {
        public static string Connection { get; set; }

        public static string randomurlRelativePath = "/v1/quotes";
    }
}
