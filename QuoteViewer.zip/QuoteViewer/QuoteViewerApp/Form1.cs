﻿using BusinessLayer.QuoteBusinessLayer;
using DataAccessLayer.QuoteDataContext;
using DomainLayer.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuoteViewerApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ConnectionInfo.Connection = "https://api.fisenko.net/v1/quotes/en/random";
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {

            Task.Factory.StartNew(() => { assigndata(); });
            buttonLoad.Enabled = false;
        }

        private void assigndata()
        {
            QuoteBusinessLayer quoteBusinessLayer = new QuoteBusinessLayer(new QuoteDataAccess());
            richTextBoxData.Text = quoteBusinessLayer.LoadData(1000);
            buttonLoad.Enabled = true;
        }

        private void buttonExport_Click(object sender, EventArgs e)
        {

        }
    }
}
